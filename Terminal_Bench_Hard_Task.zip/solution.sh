#!/bin/bash
# Oracle Solution for network-upgrade-opt
python3 solution.py
